#Twilio Details

account_sid = 'Your Account SID'
auth_token = 'Your Token Twilio'
twilionumber = '+1478249582'
twiliosmsnumber = '+1478249582'

#FC Bot
API_TOKEN = 'telegram bot api token here'
#'5554934958:AAH6AP0QuVzx0aGvsbxGERMrl45501l-m6k'
#Host URL
callurl = 'https://2395-103-251-55-48.ngrok.io'
#'https://a3702bf898c2.ngrok.io'
twiliosmsurl = 'https://2395-103-251-55-48.ngrok.io/sms'
#'https://a3702bf898c2.ngrok.io/sms'









